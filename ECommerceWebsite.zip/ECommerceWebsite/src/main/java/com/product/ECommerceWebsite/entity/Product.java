package com.product.ECommerceWebsite.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	
	@Size(min=3,max=100,message="Product name should not be minimum 3 characters and maximum 100 characters")
	private String productName;
	
	@Size(min=3,max=400,message="Product description should be minimum 3 characters and maximum 400 characters")
	private String productDescription;
	
	private String review;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return productDescription;
	}

	public void setDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}
	
}
