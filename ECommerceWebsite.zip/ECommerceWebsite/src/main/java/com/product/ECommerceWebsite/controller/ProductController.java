package com.product.ECommerceWebsite.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.ECommerceWebsite.entity.Product;
import com.product.ECommerceWebsite.exception.ProductNotFoundException;
import com.product.ECommerceWebsite.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService productService;
	
	/*Display homepage of product*/
	@GetMapping(path="/")
	public String displayHomePage(){
		return "Welcome to ECommerce Website";
	}
	
	/*Fetch all the products detail*/
	@GetMapping(path="/products")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	/*Fetch product by ID*/
	@GetMapping(path="/products/{id}")
	public Product getProductDetails(@PathVariable ("id") Integer Id){
		Product product = productService.getProductById(Id);
		if(product == null) {
			throw new ProductNotFoundException("Product id" + Id +"not found");
		}
		return product;
	}
	
	/*Fetch product by name*/
	@GetMapping(path="/products/name/{name}")
	public List<Product> getProductByName(@PathVariable ("name") String name){
		return productService.getProductByName(name);
	}
	
	/*Add new product*/
	@PostMapping(path="/products")
	public void addProduct(@Valid @RequestBody Product product){
		productService.addProduct(product);
	}
	
	/*Update product*/
	@PutMapping(path="/products")
	public void updateProduct(@RequestBody Product product){
		productService.updateProduct(product);
	}
	
	/*Delete product*/
	@DeleteMapping(path="/products/{id}")
	public void deleteProduct (@PathVariable("id") Integer productId){
		productService.deleteProduct(productId);
	}
}
