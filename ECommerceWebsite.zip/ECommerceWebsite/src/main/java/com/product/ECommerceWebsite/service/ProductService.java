package com.product.ECommerceWebsite.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.ECommerceWebsite.entity.Product;
import com.product.ECommerceWebsite.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	ProductRepository productRepository;

	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	public Product getProductById(Integer productId) {
		Product product = productRepository.findByProductId(productId);
		return product;
	}
	
	public List<Product> getProductByName(String productName) {
		return productRepository.findByProductName(productName);
	}
	
	public void addProduct(Product product) {
		productRepository.save(product);
	}

	public void updateProduct(Product product) {
		Product prod = productRepository.findByProductId(product.getProductId());
		if(prod!= null) {
			prod.setProductName(product.getProductName());
			prod.setDescription(product.getDescription());
			prod.setReview(product.getReview());
			productRepository.save(product);
		}
	}

	public void deleteProduct(Integer id) {
		productRepository.deleteById(id);
	}
}
